import Head from "next/head";

export default function HomeIt () {
    return (
        <>
            <Head>
                <title>ITA</title>
            </Head>
            <main>
                <h1>Italian Site</h1>
            </main>
        </>
    );
}
