import Head from "next/head";

export default function HomeEn () {
    return (
        <>
            <Head>
                <title>ENG</title>
            </Head>
            <main>
                <h1>English Site</h1>
            </main>
        </>
    );
}
